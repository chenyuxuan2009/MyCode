#include<bits/stdc++.h>
using namespace std;
void solve()
{
    cout<<"0.0000\n";
}
int main()
{
    freopen("e.in","r",stdin);
    freopen("e.out","w",stdout);
    if(0){ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);}
    // int t;cin>>t;while(t--)
    solve();
    return 0;
}